#pragma once

#define HTTP_SERVER "104.248.174.118"
#define HTTP_PORT 80

#define TFTP_SERVER "104.248.174.118"
